package com.example.moviedemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieprojectApplication.class, args);
	}

}
