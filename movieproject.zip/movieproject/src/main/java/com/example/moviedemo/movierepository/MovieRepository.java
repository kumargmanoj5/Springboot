package com.example.moviedemo.movierepository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.moviedemo.movie.Movie;

@Repository
public interface MovieRepository extends JpaRepository<Movie, Long> {
	
	List <Movie> findListofMoviesbyActor(String name);

}
