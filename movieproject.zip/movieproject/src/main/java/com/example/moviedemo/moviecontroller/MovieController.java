package com.example.moviedemo.moviecontroller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.moviedemo.movie.Movie;
import com.example.moviedemo.movierepository.MovieRepository;

@Controller
public class MovieController {
	
	@Autowired	
    private MovieRepository movieRepository;
	
	@RequestMapping(method=RequestMethod.GET,value="/movie/{actor}")
	public String getmovielist(@PathVariable ("actor") String name ,Model model) {
		
	
        
	/**	List<Movie> MovieList = new ArrayList<Movie>();
		
		Movie m1 = new Movie();
		m1.setName("ABC");
		m1.setDescription("Testing ABC");
		m1.setActor("Surya");
		MovieList.add(m1);
		
		Movie m2 = new Movie();
		m2.setName("DEF");
		m2.setDescription("Testing DEF");
		m2.setActor("Vijay");
	    MovieList.add(m2);
	    
	**/    
		List<Movie> MovieList =	movieRepository.findListofMoviesbyActor(name);
	    
	    model.addAttribute("M2M",MovieList);
	    
		return "movieList";
		
	}
	
	

}
