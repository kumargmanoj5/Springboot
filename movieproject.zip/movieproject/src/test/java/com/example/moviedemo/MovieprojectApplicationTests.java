package com.example.moviedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
